import streamlit as st
import random
import base64
from pathlib import Path
import streamlit.components.v1 as components

st.set_page_config(page_title="거지 탈출 RPG", page_icon="💰", layout="centered")

BASE = Path(__file__).parent
ASSETS = BASE / "assets"

STAGES = [
    ("1 STAGE · 시골 탈출", "시골", 1_000_000, "stage_1.png"),
    ("2 STAGE · 길거리 탈출", "인도 / Sidewalk", 5_000_000, "stage_2.png"),
    ("3 STAGE · 반지하 탈출", "반지하", 50_000_000, "stage_3.png"),
    ("4 STAGE · 1층 탈출", "1층 집", 250_000_000, "stage_4.png"),
    ("5 STAGE · 지방도시 탈출", "지방도시 아파트", 1_250_000_000, "stage_5.png"),
]

def init():
    defaults = {
        "money": 0,
        "stage": 0,
        "click_value": 1000,
        "extra_clicks": 0,
        "click_level": 0,
        "extra_level": 0,
        "cleared": [],
        "rps_result": "",
        "odd_result": "",
        "roulette_result": "",
        "bet": 10000,
        "effect_nonce": 0,
        "last_gain": 0,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

def won_text(n):
    if n >= 100_000_000:
        return f"{n/100_000_000:.2f}억 원"
    if n >= 10_000:
        return f"{n/10_000:.1f}만 원"
    return f"{n:,}원"

def cost(level):
    return int(1000 * (1.5 ** level))

def image_data(path):
    return base64.b64encode(path.read_bytes()).decode("utf-8")

def click_effect(amount, nonce):
    # iframe 내부 애니메이션. nonce가 매번 달라져 매 클릭마다 새로 생성된다.
    components.html(
        f"""
<div id="effect-{nonce}" style="position:relative;height:110px;background:transparent;">
  <div class="gain">+{amount:,}원</div>
</div>
<style>
.gain {{
  position:absolute;
  left:50%;
  top:18px;
  transform:translateX(-50%);
  color:#ffe45c;
  font-family:Arial,sans-serif;
  font-size:36px;
  font-weight:900;
  text-shadow:0 3px 8px #000;
  white-space:nowrap;
  animation:up-{nonce} 1s ease-out forwards;
}}
@keyframes up-{nonce} {{
  0% {{opacity:0; transform:translate(-50%,20px) scale(.75);}}
  15% {{opacity:1; transform:translate(-50%,0) scale(1.08);}}
  100% {{opacity:0; transform:translate(-50%,-80px) scale(1);}}
}}
</style>
<script>
try {{
  const C=window.AudioContext||window.webkitAudioContext;
  const a=new C();
  const o=a.createOscillator();
  const g=a.createGain();
  o.type="sine";
  o.frequency.setValueAtTime(600,a.currentTime);
  o.frequency.exponentialRampToValueAtTime(900,a.currentTime+.1);
  g.gain.setValueAtTime(.001,a.currentTime);
  g.gain.exponentialRampToValueAtTime(.08,a.currentTime+.01);
  g.gain.exponentialRampToValueAtTime(.001,a.currentTime+.15);
  o.connect(g); g.connect(a.destination);
  o.start(); o.stop(a.currentTime+.16);
}} catch(e) {{}}
</script>
""",
        height=115,
    )

init()

st.markdown("""
<style>
.stApp {
    background:linear-gradient(180deg,#171717,#080808);
    color:#fff;
}
.block-container {max-width:760px;padding-top:1rem;}
.title {text-align:center;font-size:2.3rem;font-weight:900;}
.subtitle {text-align:center;color:#999;margin-bottom:14px;}
.scene {
    position:relative;width:100%;height:auto;border-radius:22px;
    overflow:hidden;border:1px solid #444;box-shadow:0 12px 35px #0008;
}
.scene img {display:block;width:100%;height:auto;}
.character-overlay {
    position:absolute;left:50%;bottom:2%;transform:translateX(-50%);
    width:110px;filter:drop-shadow(0 7px 5px #0009);
}
.stage-name{text-align:center;font-size:1.35rem;font-weight:900;margin-top:10px;}
.description{text-align:center;color:#aaa;margin-bottom:10px;}
.card {
    background:#111;border:1px solid #383838;border-radius:18px;
    padding:16px;text-align:center;margin:10px 0;
}
.money-label{color:#999;}
.money{font-size:2.45rem;font-weight:900;color:#ffe45c;}
.income{font-size:1.12rem;font-weight:900;color:#7dff8a;margin-top:6px;}
.need{font-weight:900;color:#ffabab;margin-top:6px;}
.progress{height:14px;background:#333;border-radius:99px;overflow:hidden;margin-top:10px;}
.fill{height:100%;background:#ffe45c;}
.section{font-size:1.3rem;font-weight:900;margin:20px 0 9px;}
.shop {
    background:#191919;border:1px solid #444;border-radius:16px;
    padding:15px;min-height:145px;
}
.price{color:#ffe45c;font-weight:900;margin-top:10px;}
.gamble-card {
    background:#151515;border:1px solid #333;border-radius:16px;
    padding:14px;margin-bottom:10px;
}
div.stButton > button {
    opacity:1 !important;
    visibility:visible !important;
}
div.stButton > button[kind="secondary"] {
    background:#262626 !important;
    color:#fff !important;
    border:1px solid #666 !important;
}
div.stButton > button[kind="primary"] {
    background:#ff4b4b !important;
    color:white !important;
}
</style>
""", unsafe_allow_html=True)

stage_name, place, goal, bg_file = STAGES[st.session_state.stage]
total_click = st.session_state.click_value * (1 + st.session_state.extra_clicks)
needed = max(0, goal + 1 - st.session_state.money)
progress = min(100, st.session_state.money / goal * 100)

st.markdown('<div class="title">💸 거지 탈출 RPG</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">클릭해서 돈을 벌고 · 업그레이드하고 · 도박해서 탈출하자!</div>', unsafe_allow_html=True)

bg = image_data(ASSETS / bg_file)
character = image_data(ASSETS / "character.png")

# 실제 PNG 이미지 사용
st.markdown(
    f'<div class="scene"><img src="data:image/png;base64,{bg}"><img class="character-overlay" src="data:image/png;base64,{character}"></div>',
    unsafe_allow_html=True
)

st.markdown(f'<div class="stage-name">{stage_name}</div><div class="description">현재 지역: {place}</div>', unsafe_allow_html=True)

# HTML은 들여쓰지 않아 Streamlit이 코드 블록으로 오인하지 않도록 함
info_html = (
    '<div class="card">'
    '<div class="money-label">현재 보유 금액</div>'
    f'<div class="money">{won_text(st.session_state.money)}</div>'
    f'<div class="income">🖱️ 클릭 1회 총 수익: +{total_click:,}원</div>'
    f'<div class="need">🎯 클리어까지 {won_text(needed)}</div>'
    f'<div class="money-label">목표: {won_text(goal)} 초과</div>'
    f'<div class="progress"><div class="fill" style="width:{progress:.2f}%"></div></div>'
    '</div>'
)
st.markdown(info_html, unsafe_allow_html=True)

clicked = st.button(
    f"💰 돈 벌기  +{total_click:,}원",
    type="primary",
    use_container_width=True,
    key="earn_button",
)

if clicked:
    st.session_state.money += total_click
    st.session_state.last_gain = total_click
    st.session_state.effect_nonce += 1

    if st.session_state.money > goal:
        if st.session_state.stage not in st.session_state.cleared:
            st.session_state.cleared.append(st.session_state.stage)

        if st.session_state.stage < 4:
            st.session_state.stage += 1
            st.toast("🎉 스테이지 클리어!")
        else:
            st.balloons()
            st.success("🏆 최종 탈출 성공!")

# 클릭마다 nonce가 달라져 이펙트가 매번 다시 생성됨
if st.session_state.effect_nonce > 0:
    click_effect(st.session_state.last_gain, st.session_state.effect_nonce)

st.markdown('<div class="section">🛒 상점</div>', unsafe_allow_html=True)

c1, c2 = st.columns(2)
click_cost = cost(st.session_state.click_level)
extra_cost = cost(st.session_state.extra_level)

with c1:
    st.markdown(
        f'<div class="shop"><b>💵 클릭 수익 +1,000원</b><br>'
        f'<small>레벨 {st.session_state.click_level}<br>'
        f'기본 클릭 수익: {st.session_state.click_value:,}원</small>'
        f'<div class="price">가격 {click_cost:,}원</div></div>',
        unsafe_allow_html=True
    )
    if st.button(
        f"구매 · {click_cost:,}원",
        key="click_upgrade",
        use_container_width=True,
        disabled=st.session_state.money < click_cost
    ):
        st.session_state.money -= click_cost
        st.session_state.click_value += 1000
        st.session_state.click_level += 1
        st.rerun()

with c2:
    st.markdown(
        f'<div class="shop"><b>⚡ 클릭당 +1회 취급</b><br>'
        f'<small>레벨 {st.session_state.extra_level}<br>'
        f'현재 클릭 취급: {1 + st.session_state.extra_clicks}회</small>'
        f'<div class="price">가격 {extra_cost:,}원</div></div>',
        unsafe_allow_html=True
    )
    if st.button(
        f"구매 · {extra_cost:,}원",
        key="extra_upgrade",
        use_container_width=True,
        disabled=st.session_state.money < extra_cost
    ):
        st.session_state.money -= extra_cost
        st.session_state.extra_clicks += 1
        st.session_state.extra_level += 1
        st.rerun()

# =========================
# 도박
# =========================
st.markdown('<div class="section">🎰 도박장</div>', unsafe_allow_html=True)

# 금액은 도박 후에도 유지
st.session_state.bet = st.number_input(
    "베팅 금액",
    min_value=0,
    max_value=int(st.session_state.money),
    value=min(int(st.session_state.bet), int(st.session_state.money)),
    step=1000,
    key="bet_input"
)

g1, g2 = st.columns(2)

with g1:
    st.markdown('<div class="gamble-card"><b>✊ 가위바위보</b><br><small>승리 시 베팅금 × 3 / 패배 시 베팅금 × 1 손실</small></div>', unsafe_allow_html=True)

    r1, r2, r3 = st.columns(3)
    with r1:
        rock = st.button("✊ 바위", key="rock", use_container_width=True, disabled=st.session_state.bet <= 0)
    with r2:
        scissors = st.button("✌️ 가위", key="scissors", use_container_width=True, disabled=st.session_state.bet <= 0)
    with r3:
        paper = st.button("🖐️ 보", key="paper", use_container_width=True, disabled=st.session_state.bet <= 0)

    if rock or scissors or paper:
        player = "바위" if rock else ("가위" if scissors else "보")
        enemy = random.choice(["바위", "가위", "보"])

        if player == enemy:
            result = f"🤝 무승부! 상대: {enemy} · 베팅금 반환"
        elif (player == "바위" and enemy == "가위") or (player == "가위" and enemy == "보") or (player == "보" and enemy == "바위"):
            profit = st.session_state.bet * 3
            st.session_state.money += profit
            result = f"🎉 승리! 상대: {enemy} · +{profit:,}원 (3배)"
        else:
            loss = st.session_state.bet
            st.session_state.money -= loss
            result = f"💀 패배! 상대: {enemy} · -{loss:,}원"

        st.session_state.rps_result = result
        st.rerun()

    if st.session_state.rps_result:
        st.info(st.session_state.rps_result)

with g2:
    st.markdown('<div class="gamble-card"><b>🪙 홀짝</b><br><small>정답 시 베팅금 × 3 / 실패 시 베팅금 × 1 손실</small></div>', unsafe_allow_html=True)

    o1, o2 = st.columns(2)
    with o1:
        odd = st.button("⭕ 홀", key="odd", use_container_width=True, disabled=st.session_state.bet <= 0)
    with o2:
        even = st.button("⚫ 짝", key="even", use_container_width=True, disabled=st.session_state.bet <= 0)

    if odd or even:
        player = "홀" if odd else "짝"
        number = random.randint(1, 100)
        answer = "홀" if number % 2 else "짝"

        if player == answer:
            profit = st.session_state.bet * 3
            st.session_state.money += profit
            result = f"🎉 정답! {number} → {answer} · +{profit:,}원 (3배)"
        else:
            loss = st.session_state.bet
            st.session_state.money -= loss
            result = f"💀 실패! {number} → {answer} · -{loss:,}원"

        st.session_state.odd_result = result
        st.rerun()

    if st.session_state.odd_result:
        st.info(st.session_state.odd_result)

# 룰렛
st.markdown("#### 🎡 룰렛")
roulette_choice = st.selectbox(
    "룰렛 종류",
    [
        "💰 10만원 룰렛",
        "💰 100만원 룰렛",
        "💰 1000만원 룰렛"
    ],
    key="roulette_type"
)

roulette_base = {
    "💰 10만원 룰렛": 100_000,
    "💰 100만원 룰렛": 1_000_000,
    "💰 1000만원 룰렛": 10_000_000
}[roulette_choice]

st.caption("최대 1000배까지 당첨될 수 있습니다. 꽝이면 베팅금만 잃습니다.")

if st.button(
    f"🎡 {won_text(roulette_base)} 룰렛 돌리기",
    key="roulette",
    use_container_width=True,
    disabled=st.session_state.money < roulette_base
):
    # 1000배는 매우 낮은 확률. 배율 0은 꽝.
    weights = [700, 180, 70, 30, 15, 4, 1]
    multipliers = [0, 2, 3, 10, 50, 100, 1000]
    multiplier = random.choices(multipliers, weights=weights, k=1)[0]

    st.session_state.money -= roulette_base

    if multiplier == 0:
        result = f"💥 꽝! {won_text(roulette_base)}을 잃었습니다."
    else:
        reward = roulette_base * multiplier
        st.session_state.money += reward
        result = f"🎉 {multiplier}배 당첨! +{won_text(reward)}"

    st.session_state.roulette_result = result
    st.rerun()

if st.session_state.roulette_result:
    st.info(st.session_state.roulette_result)

# 진행도
st.markdown('<div class="section">🗺️ 탈출 진행도</div>', unsafe_allow_html=True)

for i, (name, place, target, img) in enumerate(STAGES):
    if i in st.session_state.cleared:
        status = "✅ 클리어"
    elif i == st.session_state.stage:
        status = "🔥 진행 중"
    else:
        status = "🔒 잠김"

    row = (
        '<div style="padding:11px;margin:5px 0;background:#171717;border-radius:12px;'
        'display:flex;justify-content:space-between;border:1px solid #292929;">'
        f'<b>{name}</b><span style="color:#aaa">{won_text(target)} · {status}</span>'
        '</div>'
    )
    st.markdown(row, unsafe_allow_html=True)

st.divider()

if st.button("🔄 게임 처음부터", use_container_width=True, key="reset"):
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    st.rerun()
